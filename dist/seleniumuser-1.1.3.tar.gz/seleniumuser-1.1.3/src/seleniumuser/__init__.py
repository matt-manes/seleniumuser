from .seleniumuser import User

__version__ = "1.1.3"
