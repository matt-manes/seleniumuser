# Changelog

## 1.1.0 (2023-04-03)

#### New Features

* add random 'click' chance option to fill_next


## v1.0.4 (2023-03-22)

#### Others

* build v1.0.4
* update readme


## v1.0.3 (2023-02-05)

#### Fixes

* fix duplicate dependency listings
* add readme field to pyproject.toml
#### Others

* build v1.0.3
* update changelog
* build v1.0.2
* build v1.0.2


## v1.0.2 (2023-02-02)

#### Fixes

* remove file creation from close_browser()
#### Others

* update changelog


## v1.0.1 (2023-02-02)

#### Performance improvements

* add atexit register for close_browser()
#### Others

* add changelog
* build 1.0.1


## v1.0.0 (2023-01-21)
