# Changelog

## 1.0.1 (2023-02-02)

#### Performance improvements

* add atexit register for close_browser()
#### Others

* build 1.0.1


## v1.0.0 (2023-01-21)
